create definer = rootadmin@`%` event e_sync_sales on schedule
    every '1' DAY
        starts '2018-05-11 08:00:01'
    on completion preserve
    enable
    do
    CALL p_sync_tables_sales();

