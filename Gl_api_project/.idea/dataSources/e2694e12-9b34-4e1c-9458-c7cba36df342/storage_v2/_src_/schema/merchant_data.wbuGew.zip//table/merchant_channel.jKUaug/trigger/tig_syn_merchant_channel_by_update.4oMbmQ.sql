create definer = rootadmin@`%` trigger tig_syn_merchant_channel_by_update
    after update
    on merchant_channel
    for each row
BEGIN
	DECLARE
		de VARCHAR ( 128 );
	IF
	(new.agent_no <> old.agent_no or new.agent_no is null or old.agent_no is null)
	OR (new.dist_agent <> old.dist_agent  or new.dist_agent is null or old.dist_agent is null)
	OR (new.parent_agent <> old.parent_agent or new.parent_agent is null or old.parent_agent is null)
	OR (new.salesman_no <> old.salesman_no or new.salesman_no is null or old.salesman_no is null)
	 THEN
			UPDATE settlement_data.sync_merchant_channel t 
			SET 
				t.organ_no = new.organ_no,
				t.dist_agent = new.dist_agent,
				t.parent_agent = new.parent_agent,
				t.agent_no = new.agent_no,
				t.inviteAgent_no = new.inviteAgent_no,
				t.salesman_no = new.salesman_no,
				t.create_time = new.create_time,
				t.modify_time = new.modify_time
		WHERE
			t.merchant_no = old.merchant_no
			and t.organ_no=old.organ_no;	
		END IF;
END;

