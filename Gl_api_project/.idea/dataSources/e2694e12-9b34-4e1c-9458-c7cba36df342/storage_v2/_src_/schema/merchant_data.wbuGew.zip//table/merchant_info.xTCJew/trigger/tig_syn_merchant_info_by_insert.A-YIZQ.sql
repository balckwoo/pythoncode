create definer = rootadmin@`%` trigger tig_syn_merchant_info_by_insert
    after insert
    on merchant_info
    for each row
BEGIN

	DECLARE

		de VARCHAR ( 128 );

	INSERT INTO settlement_data.sync_merchant_info (

		merchant_id,

		merchant_no,

		channel_id,

		parent_merchant_no,

		category_id,

		merchant_type,

		merchant_name,

		merchant_shortname,

		province,

		city,

		district,

		town,

		bus_area_id,

		longitude,

		latitude,

		business_licence_no,

		registered_address,

		business_address,

		master_name,

		master_cert_no,

		master_tel,

		office_tel,

		offfice_contact,

		bailor,

		bailor_cert_no,

		email,

		open_bank_name,

		open_bank_no,

		bank_account_no,

		bank_account_type,

		bank_account_name,

		client_show,

		have_pos,

		sale_rate,

		merchant_desc,

		specialty,

		main_image,

		Logo_image,

		bus_line,

		business_time,

		hot_level,

		gl_contract_no,

		order_num,

		url,

		qq,

		landmark,

		avg_price,

		agent_no,

		agent_operator_id,

		marketer_id,

		comm_key,

		gl_fee_rate,

		gl_fee_type,

		dev_user_fee_rate,

		ld_sale,

		`status`,

		operator_count,

		remark,

		create_time,

		create_by,

		modify_time,

		bank_level,

		modify_by,

		lable,

		settle_type,

		web_pay_free_rate,

		fft_pay_agent_sn,

		is_upload,

		app_pay_free_rate,

		comment_total,

		comment_count,

		liquidation_id,

		lbs_id,

		bar_code,

		join_type,

		default_sale_rate,

		link_type,

		no_benefit,

		honest_flag,

		discount_rate,

		hot_count ,

		mobile_area_code,

		salesman_no,	

		coop_partner_no

	)

	VALUES

		(

			new.merchant_id,

			new.merchant_no,

			new.channel_id,

			new.parent_merchant_no,

			new.category_id,

			new.merchant_type,

			new.merchant_name,

			new.merchant_shortname,

			new.province,

			new.city,

			new.district,

			new.town,

			new.bus_area_id,

			new.longitude,

			new.latitude,

			new.business_licence_no,

			new.registered_address,

			new.business_address,

			new.master_name,

			new.master_cert_no,

			new.master_tel,

			new.office_tel,

			new.offfice_contact,

			new.bailor,

			new.bailor_cert_no,

			new.email,

			new.open_bank_name,

			new.open_bank_no,

			new.bank_account_no,

			new.bank_account_type,

			new.bank_account_name,

			new.client_show,

			new.have_pos,

			new.sale_rate,

			new.merchant_desc,

			new.specialty,

			new.main_image,

			new.Logo_image,

			new.bus_line,

			new.business_time,

			new.hot_level,

			new.gl_contract_no,

			new.order_num,

			new.url,

			new.qq,

			new.landmark,

			new.avg_price,

			new.agent_no,

			new.agent_operator_id,

			new.marketer_id,

			new.comm_key,

			new.gl_fee_rate,

			new.gl_fee_type,

			new.dev_user_fee_rate,

			new.ld_sale,

			new.`status`,

			new.operator_count,

			new.remark,

			new.create_time,

			new.create_by,

			new.modify_time,

			new.bank_level,

			new.modify_by,

			new.lable,

			new.settle_type,

			new.web_pay_free_rate,

			new.fft_pay_agent_sn,

			new.is_upload,

			new.app_pay_free_rate,

			new.comment_total,

			new.comment_count,

			new.liquidation_id,

			new.lbs_id,

			new.bar_code,

			new.join_type,

			new.default_sale_rate,

			new.link_type,

			new.no_benefit,

			new.honest_flag,

			new.discount_rate,

			new.hot_count ,

			new.mobile_area_code,

			new.salesman_no,

			new.coop_partner_no

		);

	

END;

