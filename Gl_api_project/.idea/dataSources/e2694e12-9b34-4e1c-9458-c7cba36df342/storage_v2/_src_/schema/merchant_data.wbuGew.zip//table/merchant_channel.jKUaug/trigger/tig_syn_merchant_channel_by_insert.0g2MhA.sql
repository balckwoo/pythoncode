create definer = rootadmin@`%` trigger tig_syn_merchant_channel_by_insert
    after insert
    on merchant_channel
    for each row
BEGIN
	DECLARE
		de VARCHAR ( 128 );
	INSERT INTO settlement_data.sync_merchant_channel (
				merchant_no,
				organ_no,
				dist_agent,
				parent_agent,
				agent_no,
				inviteAgent_no,
				salesman_no,
				create_time,
				modify_time
	)
	VALUES
		(
			 new.merchant_no,
			 new.organ_no,
			 new.dist_agent,
			 new.parent_agent,
			 new.agent_no,
			 new.inviteAgent_no,
			 new.salesman_no,
			 new.create_time,
			 new.modify_time
		);
	
END;

