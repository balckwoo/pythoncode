create definer = rootadmin@`%` event e_sync_tables on schedule
    every '1' DAY
        starts '2018-03-08 00:00:01'
    on completion preserve
    enable
    do
    CALL p_sync_tables();

