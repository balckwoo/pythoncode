create definer = rootadmin@`%` trigger tig_syn_merchant_info_by_update
    after update
    on merchant_info
    for each row
BEGIN

	DECLARE

		de VARCHAR ( 128 );

	IF

		(new.merchant_name <> old.merchant_name or  old.merchant_name is null or new.merchant_name is null)

		OR (new.merchant_shortname <> old.merchant_shortname  or  old.merchant_shortname is null or new.merchant_shortname is null)

		OR (new.province <> old.province or  old.province is null or new.province is null )

		OR (new.city <> old.city or  old.city is null or new.city is null)

		OR (new.district <> old.district  or  old.district is null or new.district is null)

		OR (new.master_name <> old.master_name or  old.master_name is null or new.master_name is null )

		OR (new.master_tel <> old.master_tel  or  old.master_tel is null or new.master_tel is null)

		OR (new.office_tel <> old.office_tel or  old.office_tel is null or new.office_tel is null)

		OR (new.offfice_contact <> old.offfice_contact or  old.offfice_contact is null or new.offfice_contact is null )

		OR (new.main_image <> old.main_image or  old.main_image is null or new.main_image is null )

		OR (new.Logo_image <> old.Logo_image  or  old.Logo_image is null or new.Logo_image is null)

		OR (new.discount_rate <> old.discount_rate  or  old.discount_rate is null or new.discount_rate is null)

		OR (new.registered_address <> old.registered_address or  old.registered_address is null or new.registered_address is null ) 

		OR (new.business_address <> old.business_address or  old.business_address is null or new.business_address is null )

		OR (new.`status` <> old.`status` or old.`status` is null or new.`status` is null)

		OR (new.liquidation_id <> old.liquidation_id or old.liquidation_id is null or  new.liquidation_id is null )

		OR (new.agent_no <> old.agent_no or old.agent_no is null or  new.agent_no is null )

		OR (new.mobile_area_code <> old.mobile_area_code or old.mobile_area_code is null or  new.mobile_area_code is null )

		OR (new.parent_merchant_no <> old.parent_merchant_no or old.parent_merchant_no is null or  new.parent_merchant_no is null )

		OR (new.merchant_type <> old.merchant_type or old.merchant_type is null or  new.merchant_type is null )

		OR (new.link_type <> old.link_type or old.link_type is null or  new.link_type is null )

		OR (new.salesman_no <> old.salesman_no or old.salesman_no is null or  new.salesman_no is null )

		THEN

			UPDATE settlement_data.sync_merchant_info t 

			SET t.merchant_no = new.merchant_no,

			t.channel_id = new.channel_id,

			t.parent_merchant_no = new.parent_merchant_no,

			t.category_id = new.category_id,

			t.merchant_type = new.merchant_type,

			t.merchant_name = new.merchant_name,

			t.merchant_shortname = new.merchant_shortname,

			t.province = new.province,

			t.city = new.city,

			t.district = new.district,

			t.town = new.town,

			t.bus_area_id = new.bus_area_id,

			t.longitude = new.longitude,

			t.latitude = new.latitude,

			t.business_licence_no = new.business_licence_no,

			t.registered_address = new.registered_address,

			t.business_address = new.business_address,

			t.master_name = new.master_name,

			t.master_cert_no = new.master_cert_no,

			t.master_tel = new.master_tel,

			t.office_tel = new.office_tel,

			t.offfice_contact = new.offfice_contact,

			t.bailor = new.bailor,

			t.bailor_cert_no = new.bailor_cert_no,

			t.email = new.email,

			t.open_bank_name = new.open_bank_name,

			t.open_bank_no = new.open_bank_no,

			t.bank_account_no = new.bank_account_no,

			t.bank_account_type = new.bank_account_type,

			t.bank_account_name = new.bank_account_name,

			t.client_show = new.client_show,

			t.have_pos = new.have_pos,

			t.sale_rate = new.sale_rate,

			t.merchant_desc = new.merchant_desc,

			t.specialty = new.specialty,

			t.main_image = new.main_image,

			t.Logo_image = new.Logo_image,

			t.bus_line = new.bus_line,

			t.business_time = new.business_time,

			t.hot_level = new.hot_level,

			t.gl_contract_no = new.gl_contract_no,

			t.order_num = new.order_num,

			t.url = new.url,

			t.qq = new.qq,

			t.landmark = new.landmark,

			t.avg_price = new.avg_price,

			t.agent_no = new.agent_no,

			t.agent_operator_id = new.agent_operator_id,

			t.marketer_id = new.marketer_id,

			t.comm_key = new.comm_key,

			t.gl_fee_rate = new.gl_fee_rate,

			t.gl_fee_type = new.gl_fee_type,

			t.dev_user_fee_rate = new.dev_user_fee_rate,

			t.ld_sale = new.ld_sale,

			t.`status` = new.`status`,

			t.operator_count = new.operator_count,

			t.remark = new.remark,

			t.create_time = new.create_time,

			t.create_by = new.create_by,

			t.modify_time = new.modify_time,

			t.bank_level = new.bank_level,

			t.modify_by = new.modify_by,

			t.lable = new.lable,

			t.settle_type = new.settle_type,

			t.web_pay_free_rate = new.web_pay_free_rate,

			t.fft_pay_agent_sn = new.fft_pay_agent_sn,

			t.is_upload = new.is_upload,

			t.app_pay_free_rate = new.app_pay_free_rate,

			t.comment_total = new.comment_total,

			t.comment_count = new.comment_count,

			t.liquidation_id = new.liquidation_id,

			t.lbs_id = new.lbs_id,

			t.bar_code = new.bar_code,

			t.join_type = new.join_type,

			t.default_sale_rate =new.default_sale_rate,

		    t.link_type =new.link_type,

			t.no_benefit = new.no_benefit,

			t.honest_flag = new.honest_flag,

			t.discount_rate = new.discount_rate,

			t.hot_count = new.hot_count ,

			t.mobile_area_code = new.mobile_area_code ,

			t.salesman_no = new.salesman_no,

	    t.coop_partner_no = new.coop_partner_no

		WHERE

			t.merchant_id = old.merchant_id;			

		END IF;

	

END;

