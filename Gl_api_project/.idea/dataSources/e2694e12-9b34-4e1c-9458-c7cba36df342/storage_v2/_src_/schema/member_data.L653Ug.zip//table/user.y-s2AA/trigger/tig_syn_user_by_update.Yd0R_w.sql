create definer = account_logic@`%` trigger tig_syn_user_by_update
    after update
    on user
    for each row
begin 
                DECLARE de  VARCHAR(128);
								           	IF (new.real_name <> old.real_name or new.real_name is null  or old.real_name is null )
														OR (new.nick_name <> old.nick_name or new.nick_name is null  or old.nick_name is null)
														OR (new.mobile_phone <> old.mobile_phone or new.mobile_phone is null  or old.mobile_phone is null )
														OR (new.recommend_by <> old.recommend_by  or new.recommend_by is null  or old.recommend_by is null)
														OR (new.`status` <> old.`status`  or new.`status` is null  or old.`status` is null)
														OR (new.recommend_shop_manager <> old.recommend_shop_manager  or new.recommend_shop_manager is null  or old.recommend_shop_manager is null)
														OR (new.recommend_agent_type <> old.recommend_agent_type or new.recommend_agent_type is null  or old.recommend_agent_type is null )
														OR (new.recommend_agent_id <> old.recommend_agent_id  or new.recommend_agent_id is null  or old.recommend_agent_id is null)
														OR (new.owner_agent_no <> old.owner_agent_no or new.owner_agent_no is null  or old.owner_agent_no is null)
													    OR (new.maintain_agent_no <> old.maintain_agent_no or new.maintain_agent_no is null  or old.maintain_agent_no is null)
														OR (new.cy_bind_flag <> old.cy_bind_flag or new.cy_bind_flag is null  or old.cy_bind_flag is null)
														OR (new.cy_bind_time <> old.cy_bind_time or new.cy_bind_time is null  or old.cy_bind_time is null)
														OR (new.cy_protocol_flag <> old.cy_protocol_flag or new.cy_protocol_flag is null  or old.cy_protocol_flag is null)
														OR (new.cy_first_auth_flag <> old.cy_first_auth_flag or new.cy_first_auth_flag is null  or old.cy_first_auth_flag is null)
														OR (new.recommend_user_id <> old.recommend_user_id or new.recommend_user_id is null  or old.recommend_user_id is null)
														OR (new.recommend_init_user_id <> old.recommend_init_user_id or new.recommend_init_user_id is null  or old.recommend_init_user_id is null)
														OR (new.recommend_user_time <> old.recommend_user_time or new.recommend_user_time is null  or old.recommend_user_time is null)
														OR (new.member_agent_id <> old.member_agent_id or new.member_agent_id is null  or old.member_agent_id is null)
														OR (new.member_agent_time <> old.member_agent_time or new.member_agent_time is null  or old.member_agent_time is null)
													 THEN
                          update settlement_data.sync_user t set 
																				 t.real_name= new.real_name,
																				 t.english_name= new.english_name,
																				 t.nick_name= new.nick_name,
																				 t.`password`= new.`password`,
																				 t.mobile_phone= new.mobile_phone,
																				 t.sex= new.sex,
																				 t.birthday=new.birthday,
																				 t.cert_type=new.cert_type,
																				 t.cert_num=new.cert_num,
																				 t.email= new.email,
																				 t.`level`= new.`level`,
																				 t.signature=new.signature,
																				 t.photo=new.photo,
																				 t.province=new.province,
																				 t.city=new.city,
																				 t.district=new.district,
																				 t.town=new.town,
																				 t.register_type=new.register_type,
																				 t.register_time=new.register_time,
																				 t.auth_status=new.auth_status,
																				 t.recommend_by=new.recommend_by,
																				 t.last_login_datetime=new.last_login_datetime,
																				 t.last_login_ip=new.last_login_ip,
																				 t.`status`=new.`status`,
																				 t.modify_time=new.modify_time,
																				 t.modify_by=new.modify_by,
																				 t.remark=new.remark,
																				 t.enable_happycoin=new.enable_happycoin,
																				 t.account_protect=new.account_protect,
																				 t.recommend_shop_manager=new.recommend_shop_manager,
																				 t.recommend_agent_type=new.recommend_agent_type,
																				 t.recommend_agent_id=new.recommend_agent_id,
																				 t.buy_status=new.buy_status,
																				 t.id_address=new.id_address,
																				 t.activeId=new.activeId,
																				 t.register_channel=new.register_channel,
																				 t.owner_agent_no=new.owner_agent_no,	
																				 t.recommend_time=new.recommend_time,		
																				 t.maintain_agent_no=new.maintain_agent_no,
																				t.cy_bind_flag=new.cy_bind_flag,
																				t.cy_bind_time=new.cy_bind_time,
																				t.cy_protocol_flag=new.cy_protocol_flag,
																				t.cy_first_auth_flag=new.cy_first_auth_flag,
																				t.recommend_user_id=new.recommend_user_id,
																				t.recommend_init_user_id=new.recommend_init_user_id,
																				t.recommend_user_time=new.recommend_user_time,
																				t.member_agent_id=new.member_agent_id,
																				t.member_agent_time=new.member_agent_time																					
																				 where t.user_id=old.user_id;
                    
               end IF;
 END;

