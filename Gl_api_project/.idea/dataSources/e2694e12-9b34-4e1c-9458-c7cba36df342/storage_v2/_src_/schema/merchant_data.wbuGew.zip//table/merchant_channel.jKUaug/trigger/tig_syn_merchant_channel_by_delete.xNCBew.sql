create definer = rootadmin@`%` trigger tig_syn_merchant_channel_by_delete
    after delete
    on merchant_channel
    for each row
BEGIN
	DECLARE
		de VARCHAR ( 128 );
	
		delete from  settlement_data.sync_merchant_channel 
		 WHERE
			merchant_no = old.merchant_no
      and organ_no=old.organ_no;	

	
END;

